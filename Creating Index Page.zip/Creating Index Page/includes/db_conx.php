<?php 

$conx = mysqli_connect("localhost","root","", "shop");

?>