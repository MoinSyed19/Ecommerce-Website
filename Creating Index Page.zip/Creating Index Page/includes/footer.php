<body >		<footer id="footer" style="background-color:#2554C7;">
			
			<div class="footer-bottom" style="background-color:#2554C7;">
			<div class= "container-fluid" style="background-color:#2554C7;">
				<div class="row" style="background-color:#2554C7;">
				
				<div class ="col-lg-5 col-md-4 copyright">
					Copyright &copy; 2021<strong> | FashMart</strong>  All Rights Reserved
				
					<div class ="credits">
						Developed by <a style="color:yellow;" href="#">Moin Syed</a>

					</div>
				
				</div>

				<div class="col-lg-6 col-md-4 credit-cards" >
 					 <img class="ico-img" height="30px" width="45px" src="https://shoplineimg.com/assets/footer/card_visa.png"/>
 					 <img  class="ico-img" height="30px" width="45px" src="https://brand.mastercard.com/content/dam/mccom/brandcenter/thumbnails/mastercard_vrt_pos_92px_2x.png"/>
 					 <img class="ico-img" height="30px" src="https://shoplineimg.com/assets/footer/card_paypal.png"/>
 					 <img class="ico-img" height="30px" width="45px"src="https://cdn0.iconfinder.com/data/icons/payment-method/480/rupay_payment_card_bank-512.png"/>
 					 <img class="ico-img" height="30px" width="45px" src="https://paymentweek.com/wp-content/uploads/2018/02/googlepaylogotitle.jpg"/>
 					 <img class="ico-img" height="30px" width="45px" src="https://cdn2.iconfinder.com/data/icons/social-icons-color/512/paytm-512.png"/>


			   </div>
			  
				
				</div>
				
			</div>
			</div>

		</footer>
	
	</body>
</html>
<?php include("db_conx_close.php");?>