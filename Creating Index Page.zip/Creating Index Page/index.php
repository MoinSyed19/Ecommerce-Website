<?php
    include('includes/header.php');
?>
<head>
      
      <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
      <script src="https://unpkg.com/popper.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="includes/autocomplete.js" ></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/style-header.css">
       <link rel="stylesheet" href="css/fstyle.css">
       <script data-ad-client="ca-pub-1336038489175991" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
       
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<script src="dist/bootstrap-swipe-carousel.min.js"></script>

   <style >
    .carousel-control-prev-icon,
.carousel-control-next-icon {
  
  outline: black;
  background-image: none;
}

.carousel-control-next-icon:after
{
  content: '';
  font-size: 40px;
  color:#333333;
}

.carousel-control-prev-icon:after {
  content: '';
 font-size: 40px;
  color:#333333;

}
    h5 {
  display: inline-block;
  padding: 10px;
  background: #B9121B;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.p {
  text-align: center;
  padding-top: 40px;
  font-size: 13px;

}
.carousel-item{
    height: 800px;
} 
    .carousel-image{
  display: block;
  width:100%;
  height:800px;
  object-fit:cover;
}

.carousel-indicators{
  z-index:1;
}
:root{

  --text-light: rgba(255,255,255,0.6);
  --text-lighter: rgba(255,255,255,0.9);
  --spacing-s: 5px;
  --spacing-m: 16px;
  --spacing-l: 16px;
  --spacing-xl: 36px;
  --spacing-xxl: 64px;
  --width-container: 1200px;
}

*{
  border: 0;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html{

  font-family: 'Montserrat', sans-serif;
  font-size: 14px;
}


.card-grid{
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  grid-column-gap: var(--spacing-l);
  grid-row-gap: var(--spacing-l);
  max-width: var(--width-container);
  width: 100%;

  
}
@media(min-width: 100px)
{
  .card-grid{
    grid-template-columns: repeat(2, 1fr); 
  }
  .card{
    height:195px;
  }
  .containermy {

  width: 10px;
  height: 20px;
  
  display: grid;
  border-radius: 5px;
  grid-template-columns: 75px 75px;
  grid-row: auto auto;
  grid-column-gap: 6px;
  grid-row-gap: 6px;
}

.containermy .boxmy {
   
  padding: 5px;
  border-radius: 5px;
  color: #fff;
  border:1px solid #ddd;
  background-color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;

}
}
@media(max-width: 600px)
{
  .card-grid{
    grid-template-columns: repeat(1, 1fr); 
  }
  .card{
    height:380px;
    width:330px;
  }
  .containermy {

  padding-left:10px;
  width: 70px;
  height: 100px;
 
  display: grid;
  grid-template-columns: 130px 130px;
  grid-row: auto auto;
  grid-column-gap: 15px;
  grid-row-gap: 15px;
}

.containermy .boxmy {
   
  padding: 0px;
  height:140px;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;

}
.containermy .boxmy .pimage{
  height:100px; width:110px; 
  object-fit: contain; 
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.frame-pname{
  font-size: 10px;
  white-space: normal;
  text-align:center;

  display:inline-block;
  padding:5px;
  text-decoration:none;
  line-height: 10px;
  color:black;
  
}
.frame-1{
   background:url('img/FRAME-02.png'); 
   background-size: 330px 380px; 
   background-repeat: no-repeat;
  }
  .frame-2{
      background:url('img/FRAME-01.png'); 
      background-size: 330px 380px; 
   background-repeat: no-repeat; 
  }
  .frame-3{
    background:url('img/FRAME-02.png');
    background-size: 330px 380px; 
   background-repeat: no-repeat;
  }
.hero-section{
  
  justify-content: center;
  
  padding-left: 14px;
  margin-top:40px;
}
.hero-section1{
  
  justify-content: center;
   padding:  var(--spacing-l);
    padding-left: 14px;
}
}

@media(min-width: 576px){
  .card-grid{
    grid-template-columns: repeat(2, 1fr); 

  }
  .card{
    height:340px;
  }
  
  .containermy {

  width: 90px;
  height: 110px;
  
  display: grid;
  grid-template-columns: 135px 135px;
  grid-row: auto auto;
  grid-column-gap: 20px;
  grid-row-gap: 10px;
}

.containermy .boxmy {
   
  padding: 7px;
  
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;

}

}

@media(min-width: 960px){
  .browsing h4{
  color:black; 
  margin-top:1%; 
  display:inline-block; 
  margin-right:900px;
}
.bh_img{
  width:170px; 
  height:190px;  
  object-fit: contain; 
  padding:10px;
}
#bh_row{
    margin-left:130px;
  }
  .warn{
  text-align:center;
   margin-top:50px; 
   margin-left:350px;
    font-size: 25px;
}
  .carousel-item{
    height: 500px;
} 
.carousel-image{
  display: block;
  width:100%;
  height:500px;
  object-fit:cover;
}

  .card-grid{
    grid-template-columns: repeat(3, 1fr); 
  }
  .card{
    height: 450px;
    width: 420px;

  }
 .frame-1{
   background:url('img/FRAME-02.png'); 
   background-size: 420px 450px; 
   background-repeat: no-repeat;
  }
  .frame-2{
      background:url('img/FRAME-01.png'); 
      background-size: 420px 450px; 
   background-repeat: no-repeat; 
  }
  .frame-3{
    background:url('img/FRAME-02.png');
    background-size: 420px 450px; 
   background-repeat: no-repeat;
  }
  .containermy {

  width: 100px;
  height: 30px;
  padding-left: 18px;
  display: grid;
  grid-template-columns: 170px 170px;
  grid-row: auto auto;
  grid-column-gap: 13px;
  grid-row-gap: 13px;
}

.containermy .boxmy {
   
  padding: 2px;
  height:170px; 
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  line-height: 12px;

}

.frame-pname{
  font-size: 12px;
  white-space: normal;
  text-align:center;

  display:block;
  padding:5px;
  text-decoration:none;
  line-height: 12px;
  color:black;
  
}
  
  
.frame-pname-samarth{
  font-size: 8px;
  white-space: normal;
  text-align:center;

  display:block;
  padding:5px;
  text-decoration:none;
  line-height: 12px;
  color:black;
  
}



.containermy .boxmy a{
  text-decoration: none;
}
.containermy .boxmy a:hover{
  text-decoration: none;
  color:black;
}
.containermy .boxmy .pimage{
  height:120px; width:140px; 
  object-fit: contain; 
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.intro {
  width: 100%;
  margin-top: 50px;
  background: linear-gradient(to right, #757f9a, #d7dde8);
  height: 250px;

  }
  .intro img {
    margin-top: 50px;
    margin-left: 100px;
    width: 20%;
    width: 230px; 
    height: 280px;

  }
  h2 {
    margin-top: -260px;
    margin-left: 29%;
    margin-right: 0%;
    font-size: 30px;
    font-weight: 400;
  }
}

.card{
  list-style: none;
  position: relative;
  border-radius: 10px;
}

.card:before{
  content: '';
  display: block;
  padding-bottom: 0px;
  width: 100%;
}

.card__background{
  background-size: cover;
  background-position: center;
  border-radius: var(--spacing-l);
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  
  
}

/*.card:hover .card__background{
  transform: scale(1.05) translateZ(0);
}

.card-grid:hover > .card:not(:hover) .card__background{
  filter: brightness(0.5) saturate(0) contrast(1.2) blur(20px);
} */

.card__content{
  left: 10px;
  padding:5px ;
  position: relative;
  top: 5px;
  line-height: 3px;
}

.card__category{
  color: black;
  font-size: 0.9rem;
  margin-bottom: var(--spacing-s);
  text-transform: uppercase;
}
.card-heading{
  font-size: 1.6rem;
  color:black;

  text-shadow: 2px 2px 20px rgba(0,0,0,0.2);
}
.card-heading a{
  text-decoration: none;
}
.card-heading a:hover{
  text-decoration: none;
  color:#Ff6f3d;
}
/*.container .nav1 h1 {
    width: 240px;
    float: left;
    margin-top: 7px;
    
}

/* .container h1 a{
    text-decoration: none;
    color: black;
} */
/*
.container .nav1 {
    padding: 0px 10px;
    overflow: hidden;
}

.container .nav1 ul {
    
    float: right;
    list-style: none;
    margin-top: 15px;
    font-weight: bold;
}

.container .nav1 ul li {
    display: inline;
    margin-left: 40px;
}
.container .nav1 ul li a {
    text-decoration: none;
    color: black;
}
.container .nav1 ul li a.active{
    color: #F7DC57;
}
*/
/* items */
.items {
    margin-top: 30px;
}

/* grid 4*/
.grid-4 {
    display: grid;
    grid-template-columns: auto auto auto auto;
    column-gap: 15px;
}

/* Span */
.category {
    text-align: center;
    margin: 10px 0px;
    color: #bbb;
}

.category .new {
    color: red;
    font-style: italic;
}

/*  // span */
/* Flip card */


.flip-card {
    background-color: transparent;
    width: 100%;
    height: 300px;
    perspective: 1000px;
}

.flip-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 0.6s;
    transform-style: preserve-3d;
}

.flip-card:hover .flip-card-inner {
    transform: rotateY(180deg);
}

.flip-card-front,
.flip-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}

/* ftont card */

.flip-card-front {}

.flip-card-front img{
    width: 100%;
    height: 300px;
}


/* back card */

.flip-card-back {
    background-color: #Ff6f3d;
    color: white;
    transform: rotateY(180deg);
}

.flip-card-back .buttons {
    padding-top: 40px;
}

.flip-card-back .buttons a button {
    margin-top: 20px;
    width: 200px;
    background-color: #fff;
    height: 35px;
    text-decoration: none;
    color: #bbb;
    padding: 5px 10px;
    border: none;
}

.flip-card-back .buttons a button:hover {
    background-color:#3e503c;
    text-decoration: none;
    color: #fff;
    border: none;
    cursor: pointer;
}

.item {
    border: 1px rgb(223, 215, 215) solid;
    border-radius: 5px;
    margin-top: 5PX;
}

/* Details */

.detail {
    text-align: center;
    margin-top: 7px;
    margin-bottom: 30px;
}

.detail h1 {
    text-align: center;
}

.detail i {
    color: #Ff6f3d;
}

.detail p {
    margin: 5px;
}

.detail h1 {
    color: black;
}

/* //Details */


/* Media query */

@media only screen and (max-width: 1100px){
    .grid-4{
        grid-template-columns: auto auto;
    }
}

@media only screen and (max-width: 773px){
    /*.container .nav1 h1{
        font-size: 1.5rem;
        width: 180px;
    }
    .flip-card-back .buttons a button {
        width: 160px;
        height: 35px;
        padding: 5px 10px;
    }

    .container .nav1 ul li {
        margin-left: 20px;
    }
    */

}
@media(max-width: 600px){
.carousel-item{
    height: 170px;
  }  
  .carousel-image{
  display: block;
  width:100%;
  height:170px;
  object-fit:contain;
}
  .browsing h4{
  
  margin-right:0px;
}
  .bh_img{
    margin-top: 45px;
    margin-left:7px;
    width:50px; 
    height:50px; 
    object-fit: contain; 
       
} 
  #bh_row{
    margin-left:0px;
  }
  .warn{
  text-align:center;
   margin-top:50px; 
   margin-left:50px;
    font-size: 15px;
}
} 
@media only screen and (max-width: 600px){
    .grid-4{
        grid-template-columns: auto;
    }
   /* .nav1 ul{
        width: 100%;
    }
    .nav1 ul li{
        margin-left: 2px;
    }
  */
  
  .intro {
  width: 100%;
  margin-top: 50px;
  background: linear-gradient(to right, #757f9a, #d7dde8);
  height: 130px;

  }
  .intro img {
    margin-top: 50px;
    margin-left: 20px;
    width: 20%;
    width: 100px; 
    height: 120px;

  }
   h2 {
    margin-top: -135px;
    margin-left: 38%;
    margin-right: 10%;
    font-size: 15px;
    font-weight: 400;
  }
}

  
.line {
  display: flex;
  flex-direction: row;
  align-items: stretch;
  max-width: 90%;
  margin: 0 auto;
}

.line .item {
  line-height: 0;
  margin: 10px;
  min-width: 0;
  min-height: 0;
  cursor: pointer;
  transition: opacity .2s ease;
}

.line .item:hover {
  opacity: .6;
}

.line .item img {
  max-width: 100%;
}


@import url('https://fonts.googleapis.com/css?family=Nunito:400,700');


* {
  transition: all 0.3s ease-out;
}



h3 {
  color: #262626;
  font-size: 17px;
  line-height: 24px;
  font-weight: 700;
  margin-bottom: 4px;
}

p {
  font-size: 17px;
  font-weight: 400;
  line-height: 20px;
  color: #666666;

  &.small {
    font-size: 14px;
  }
}

.go-corner {
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  width: 32px;
  height: 32px;
  overflow: hidden;
  top: 0;
  right: 0;
  //background-color: #00838d;
  background-color: #7070ff;
  border-radius: 0 4px 0 32px;
}
/*
.go-corner {
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  width: 200px;
  height: 200px;
  overflow: hidden;
  top: 0;
  left: 0;
  //background-color: #00838d;
  background-color: red;
  border-radius: 0 4px 200px 0 ;
  opacity: 0.5;
}   */
 
.go-corner {
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  width: 70px;
  height: 70px;
  overflow: hidden;
  top: 0;
  right: 0;
  //background-color: #F0F8FF;
  background-color: darkgreen;
  border-radius: 0 4px 0 70px;
  opacity: 0.9;
 
 
}

.go-arrow {
  margin-top: -4px;
  margin-right: -4px;
  color:#fff;
  font-family: courier, sans;
  font-weight: bold;
}



.card2 {
  display: block;
  top: 0px;
  position: relative;
  max-width: 350px;
  background-color: #f2f8f9;
  border-radius: 4px;
  padding: 32px 24px;
  margin: 12px;
  text-decoration: none;
  z-index: 0;
  overflow: hidden;
  border: 1px solid #f2f8f9;

  &:hover {
    transition: all 0.2s ease-out;
    box-shadow: 0px 4px 8px rgba(38, 38, 38, 0.2);
    top: -4px;
    border: 1px solid #cccccc;
    background-color: white;
  }

  &:before {
    content: "";
    position: absolute;
    z-index: -1;
    top: -16px;
    right: -16px;
    background: #00838d;
    height: 32px;
    width: 32px;
    border-radius: 32px;
    transform: scale(2);
    transform-origin: 50% 50%;
    transition: transform 0.15s ease-out;
  }

  &:hover:before {
    transform: scale(2.15);
  }
}

.card2{
    border-radius: 4px;
    background: #fff;
    box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
      transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);
  padding: 14px 80px 18px 36px;
  cursor: pointer;
}

.card2:hover{
     transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}

#a1 {
  
  color: black;
}
#a1:hover {
  color: #008080;
}
</style>

</head>

<body>
<div class="container-fluid" style=" margin-top:120px; padding-left: 0rem; padding-right: 0rem; overflow: hidden;">

<div id="carouselExampleIndicators" class="carousel slide my-carousel"  data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
  </ol>
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="carousel-image" style="width:100%" src="images/Untitled design (1).jpg" data-color="lightblue" alt="First Image">
      <div class="carousel-caption d-md-block">
      </div>
    </div>
    <div class="carousel-item">
      <img class="carousel-image" style="width:100%" src="images/Untitled design.jpg" data-color="firebrick" alt="Second Image">
      <div class="carousel-caption d-md-block">
      </div>
    </div>
	<div class="carousel-item">
      <img class="carousel-image" style="width:100%" src="images/Untitled design (1).jpg" data-color="firebrick" alt="Second Image">
      <div class="carousel-caption d-md-block">
      </div>
    </div>
	<div class="carousel-item">
      <img class="carousel-image" style="width:100%" src="images/Untitled design.jpg" data-color="firebrick" alt="Second Image">
      <div class="carousel-caption d-md-block">
      </div>
    </div>
  
  </div>
  <!-- Controls -->
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
</div>

<script>
    $('.my-carousel').carousel().swipeCarousel({
  // low, medium or high
  sensitivity: 'medium' 
});
</script>


<div class="container-fluid" style="padding-left: 0rem; padding-right: 0rem; overflow: hidden;">
    
    <hr>
<div class="row">
    <div class="col-md-12">
    <h3>
  <center> <strong> TOP COLLECTIONS </strong> </center>
    </h3>
    </div>
</div>
<hr>

<div class="row">
	<div class="col-lg-4">
		     <a href="https://fashmart.shop/product-catalog?cat_id=2" style="text-decoration:none;" class="cta-btn">
			  <span class="card2" style="" href="#">
			     
			      
								<img src="img/watchpreview1.jpg" style="height:200px; width:260px;" alt="">
							
				
								<h3>Watch<br>Collection</h3>
								Shop now <i class="fa fa-arrow-circle-right"></i>
							
			
			  </span>
			  </a>
		</div>

<div class="col-lg-4">
    <a href="https://fashmart.shop/product-catalog?cat_id=4" style="text-decoration:none;" class="cta-btn">
			  <span class="card2" href="#">
			       <div class="shop-img">
								<img src="img/shoepreview.jpg" style="height:200px; width:260px;" alt="">
							</div>
				<div class="shop-body">
								<h3>Shoes<br>Collection</h3>
								Shop now <i class="fa fa-arrow-circle-right"></i>
							</div>
			
			  </span>
			  </a>
		</div>
	
		<div class="col-lg-4">
		    <a href="https://fashmart.shop/product-catalog?cat_id=5" style="text-decoration:none;" class="cta-btn">
			  <span class="card2" href="#">
			       <div class="shop-img">
								<img src="img/shirtpreview.jpg" style="height:200px; width: 260px;" alt="">
							</div>
				<div class="shop-body">
								<h3>Shirts<br>Collection</h3>
								Shop now <i class="fa fa-arrow-circle-right"></i>
							</div>

			  </span>
			  </a>
		</div>
</div>

<hr>
<div class="row">
    <div class="col-md-12">
    <h3>
  <center> <strong> POPULAR PRODUCTS </strong> </center>
    </h3>
    </div>
</div>
<hr>

<div class="row">
    


    
    <div class="col-sm-3">
        
		    <a href="" style="text-decoration:none;">

							
			  <span class="card2 " href="#">
			      
			       <div class="shop-img">
			           
						<img class="pic-1" src="Products Images/1.jpg"  alt="" style="height:200px; width: 260px;" onerror="this.src='my_logo.jpeg';" >
					   
					   </center>
							</div>
				
			
				    
						<div class="shop-body">
								<span style="color:black;"><?php echo '<strong>Nike(Shoes)</strong>';  ?></span>
								



						<div class="product-price" style="color:black">

						<?php echo "<sup> ₹ </sup>";echo '2000';  ?><small>&nbsp&nbsp<s><?php echo '4000'; ?></s></small>

						</div>





								Buy now <i class="fa fa-arrow-circle-right"></i>
							</div>
				
				<div class="go-corner" href="#">
				  <div class="go-arrow">
					<h6 class=""><?php echo '<strong>50% off</strong>'; ?></h6> 
				  </div>
				</div>
			  </span>
			  </a>
		</div>
	



</div>

<hr>

<div class="row">
    <div class="col-md-12">
    <h3>
  <center> <strong> PRODUCTS FOR MEN'S </strong> </center>
    </h3>
    </div>
</div>
<hr>

<div class="row">


    
    <div class="col-sm-3">
        
		    <a href="" style="text-decoration:none;">

							
			  <span class="card2" href="#">
			       <div class="shop-img">
					<center>	<img class="pic-1" src="Products Images/2.jpg"  alt="" style="height:200px; width: 260px;" onerror="this.src='my_logo.jpeg';" >
					   
					   </center>
							</div>
				
			
				    
						<div class="shop-body">
								<span style="color:black;"><?php echo '<strong>Watch(Rolex)</strong>';  ?></span>
								



						<div class="product-price" style="color:black">

						<?php echo "<sup> ₹ </sup>";echo '3000';  ?><small>&nbsp&nbsp<s><?php echo '6000'; ?></s></small>

						</div>





								Buy now <i class="fa fa-arrow-circle-right"></i>
							</div>
				
				
				<div class="go-corner" href="#">
				  <div class="go-arrow">
						<h6 class=""><?php echo '<strong>50% off</strong>'; ?></h6> 
				  </div>
				</div>
			  </span>
			  </a>
		</div>
	



</div>



<hr>
<div class="row">
    <div class="col-md-12">
    <h3>
  <center> <strong> PRODUCTS FOR WOMEN'S </strong> </center>
    </h3>
    </div>
</div>
<hr>

<div class="row">

    
    <div class="col-sm-3">
        
		    <a href="" style="text-decoration:none;">

							
			  <span class="card2" href="#">
			       <div class="shop-img">
					<center>	<img class="pic-1" src="Products Images/3.jpg"  alt="<?php echo $row['product_name'];?>" style="height:200px; width: 260px;" onerror="this.src='my_logo.jpeg';" >
					   
					   </center>
							</div>
				
			
				    
						<div class="shop-body">
								<span style="color:black;"><?php echo 'Titan(Watch)';  ?></span>
								



						<div class="product-price" style="color:black">

						<?php echo "<sup> ₹ </sup>";echo '5000';  ?><small>&nbsp&nbsp<s><?php echo '10000'; ?></s></small>

						</div>





								Buy now <i class="fa fa-arrow-circle-right"></i>
							</div>
				
			
			<div class="go-corner" href="#">
				  <div class="go-arrow">
						<h6 class=""><?php echo '<strong>50% off</strong>'; ?></h6> 
				  </div>
				</div>	
			  </span>
			  </a>
		</div>
	

</div>
</div>




<?php
   // include('includes/footer.php');
?>
 <script>
       /*
var msg = new SpeechSynthesisUtterance('Hello speak');
window.speechSynthesis.speak(msg);
*/

var msg = new SpeechSynthesisUtterance();
var voices = window.speechSynthesis.getVoices();
msg.voice = voices[39]; // Note: some voices don't support altering params
msg.voiceURI = 'native';
msg.volume = 20; // 0 to 1
msg.rate = 1; // 0.1 to 10
msg.pitch = 1; //0 to 2
msg.text = 'Welcome to Fashmart online shopping website.';
msg.lang = 'hi';

msg.onend = function(e) {
  console.log('Finished in ' + event.elapsedTime + ' seconds.');
};

speechSynthesis.speak(msg);
/*
var msg = new SpeechSynthesisUtterance('I see dead people!');
msg.voice = speechSynthesis.getVoices().filter(function(voice) { return voice.name == 'Whisper'; })[39];
speechSynthesis.speak(msg);
*/
</script> 